from crewai import Task

def create_tasks(agents, inputs):
    jd_text = inputs.get("jd_text", "")
    jd_url  = inputs.get("jd_url", "")
    resume_path = inputs.get("resume_path", "")
    linkedin_url = inputs.get("linkedin_url", "")

    jd_source = f"Job posting URL: {jd_url}" if jd_url else f"Job description text:\n{jd_text}"
    profile_source = ""
    if resume_path:
        profile_source += f"Resume PDF path: {resume_path}\n"
    if linkedin_url:
        profile_source += f"LinkedIn URL: {linkedin_url}"

    retrieve_memory = Task(
        description=(
            f"Search ChromaDB for past applications similar to this job description: {jd_text or jd_url}. "
            "Return the top 3 similar past applications to provide context."
        ),
        expected_output="A summary of up to 3 similar past applications including company, role, ATS score, and tone snippets. If none exist, return 'No past applications found.'",
        agent=agents["memory"]
    )

    analyse_jd = Task(
        description=(
            f"Analyse this job posting and extract all important information.\n{jd_source}\n\n"
            "Extract: job title, company name, required skills (list), preferred skills (list), "
            "key responsibilities, seniority level, culture signals, and the top 20 ATS keywords."
        ),
        expected_output="A structured analysis with: job title, company, required skills, preferred skills, top 20 ATS keywords, seniority level, and 3 culture signals.",
        agent=agents["jd_analyser"],
        context=[retrieve_memory]
    )

    parse_profile = Task(
        description=(
            f"Parse the candidate's profile from all available sources.\n{profile_source}\n\n"
            "Build a structured profile with: full name, professional summary, skills list, "
            "all work experience entries (role, company, dates, bullet points), education, "
            "certifications, and any notable projects."
        ),
        expected_output="A structured candidate profile with all sections clearly labelled: Summary, Skills, Experience, Education, Certifications, Projects.",
        agent=agents["profile_parser"],
        context=[retrieve_memory]
    )

    score_ats = Task(
        description=(
            "Using the JD analysis and candidate profile, calculate an ATS compatibility score.\n"
            "1. Count how many of the top 20 ATS keywords appear in the candidate profile\n"
            "2. Calculate match percentage\n"
            "3. List the missing keywords\n"
            "4. List the matched keywords\n"
            "5. Give 5 specific recommendations to improve the score"
        ),
        expected_output="ATS Score: X%. Missing keywords: [list]. Matched keywords: [list]. Top 5 recommendations: [numbered list].",
        agent=agents["ats_scorer"],
        context=[analyse_jd, parse_profile]
    )

    tailor_resume = Task(
        description=(
            "Rewrite the candidate's resume to maximise ATS score for this specific role.\n"
            "Rules:\n"
            "- Rewrite the professional summary to mirror the JD language\n"
            "- Reorder bullet points so the most JD-relevant achievements appear first\n"
            "- Naturally weave in missing ATS keywords from the gap analysis\n"
            "- Quantify any vague claims where possible\n"
            "- Keep all experience honest — reframe, never fabricate\n"
            "- Output clean markdown format"
        ),
        expected_output="Complete tailored resume in clean markdown format, ready to copy into any resume builder.",
        agent=agents["resume_tailor"],
        context=[analyse_jd, parse_profile, score_ats]
    )

    write_cover_letter = Task(
        description=(
            "Write a personalised cover letter for this application.\n"
            "Structure:\n"
            "- Opening (1 sentence): Hook with a genuine connection to the company mission or a recent company development found via search\n"
            "- Body (2 paragraphs): Map 2-3 of the candidate's strongest achievements directly to JD requirements\n"
            "- Closing (1 sentence): Confident call to action\n"
            "- Length: 250-320 words\n"
            "- Tone: Match the candidate's natural writing style from their profile"
        ),
        expected_output="Complete personalised cover letter in markdown format, 250-320 words.",
        agent=agents["cover_letter_writer"],
        context=[analyse_jd, parse_profile, score_ats]
    )

    write_cold_email = Task(
        description=(
            "Write a cold outreach email to the recruiter or hiring manager.\n"
            "Rules:\n"
            "- Search for the recruiter or hiring manager name if possible\n"
            "- Subject line: punchy, specific, under 8 words\n"
            "- Body: 3 sentences max — who you are, why this role, call to action\n"
            "- Tone: peer-level confidence, not pleading\n"
            "- Do NOT make it a mini cover letter"
        ),
        expected_output="Subject line on first line, then email body. Under 100 words total.",
        agent=agents["cold_email_writer"],
        context=[analyse_jd, parse_profile]
    )

    prep_interview = Task(
        description=(
            "Generate interview preparation material for this specific role.\n"
            "Produce:\n"
            "- 5 behavioural questions (STAR format) based on the JD responsibilities\n"
            "- 5 technical questions based on the skills and tools in the JD\n"
            "- A model answer for each question using the candidate's real experience\n"
            "Questions must be specific to this role — not generic."
        ),
        expected_output="10 questions with model answers. Format: Q1: [question]\nA1: [answer using candidate experience]\n... for all 10.",
        agent=agents["interview_prep"],
        context=[analyse_jd, parse_profile]
    )

    critique_outputs = Task(
        description=(
            "Review the tailored resume, cover letter, and cold email.\n"
            "Score each on 4 dimensions (1-10):\n"
            "1. Keyword alignment — are JD keywords present naturally?\n"
            "2. Tone consistency — does it match the candidate's voice?\n"
            "3. ATS safety — no tables, columns, headers that break parsing?\n"
            "4. Specificity — are claims concrete and quantified?\n\n"
            "If any score is below 7, provide specific rewrite instructions.\n"
            "If all scores are 7+, approve the outputs."
        ),
        expected_output="Scores for resume, cover letter, and cold email across 4 dimensions. Either APPROVED or specific rewrite instructions per item.",
        agent=agents["critic"],
        context=[tailor_resume, write_cover_letter, write_cold_email, score_ats]
    )

    save_application = Task(
        description=(
            "Save this completed application to ChromaDB memory.\n"
            "Store: company name, role title, JD summary, ATS score, "
            "tailored resume (first 500 chars), cover letter (first 500 chars), and today's date."
        ),
        expected_output="Confirmation that the application was saved successfully with its document ID.",
        agent=agents["memory"],
        context=[analyse_jd, tailor_resume, write_cover_letter, score_ats]
    )

    return {
        "retrieve_memory":    retrieve_memory,
        "analyse_jd":         analyse_jd,
        "parse_profile":      parse_profile,
        "score_ats":          score_ats,
        "tailor_resume":      tailor_resume,
        "write_cover_letter": write_cover_letter,
        "write_cold_email":   write_cold_email,
        "prep_interview":     prep_interview,
        "critique_outputs":   critique_outputs,
        "save_application":   save_application,
    }