"""
Interview Preparation Agent for the AI Job Application Tailor.
Generates role-specific interview questions and model answers based on JD and profile.
"""

import os
from dotenv import load_dotenv
from crewai import Agent, LLM

load_dotenv()

def get_interview_prep_agent() -> Agent:
    """
    Creates and returns the Interview Preparation Agent.
    
    Returns:
        Agent: A CrewAI agent configured for interview question generation.
    """
    try:
        llm = LLM(
            model="groq/llama-3.3-70b-versatile",
            api_key=os.getenv("GROQ_API_KEY")
        )
        
        return Agent(
            role="Technical Interview Coach",
            goal="Generate 10 role-specific interview questions (5 behavioral in STAR format, 5 technical based on JD skills) "
                 "and provide a model answer for each using the candidate's actual experience.",
            backstory="You are a veteran engineering manager and interview coach who has conducted over 500 technical interviews. "
                      "You know exactly what hiring managers will ask based on the job description. "
                      "You excel at helping candidates map their past experiences to expected interview questions using the STAR method.",
            llm=llm,
            verbose=True,
            allow_delegation=False
        )
    except Exception as e:
        print(f"Error initializing Interview Prep Agent: {str(e)}")
        raise
