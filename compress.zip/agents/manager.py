from crewai import Agent
from langchain_groq import ChatGroq
import os

def create_manager(llm):
    return Agent(
        role="Application Manager",
        goal="Orchestrate all sub-agents to produce a complete, high-quality job application package.",
        backstory=(
            "You are a senior career strategist with 15 years of experience helping candidates "
            "land jobs at top companies. You coordinate a team of specialist agents, validate "
            "their outputs, and ensure every application is tailored, ATS-optimised, and compelling."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=True
    )