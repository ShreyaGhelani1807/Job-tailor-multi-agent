from crewai import Agent

def create_jd_analyser(llm, tools):
    return Agent(
        role="Job Description Analyser",
        goal="Extract every important signal from a job description: required skills, preferred skills, keywords, seniority level, company culture, and ATS-critical terms.",
        backstory=(
            "You are an expert at reading job postings and identifying exactly what employers "
            "are looking for. You know how ATS systems work and can spot the exact keywords "
            "that will make or break a resume screening."
        ),
        llm=llm,
        tools=tools,
        verbose=True,
        allow_delegation=False
    )