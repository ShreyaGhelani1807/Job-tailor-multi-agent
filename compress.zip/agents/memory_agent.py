from crewai import Agent

def create_memory_agent(llm, tools):
    return Agent(
        role="Application Memory Manager",
        goal="Store completed applications to ChromaDB and retrieve similar past applications to provide context for improving current outputs.",
        backstory=(
            "You manage the long-term memory of the application system. You save every "
            "completed application as a vector embedding and retrieve the most relevant "
            "past applications when working on a new one, helping the system learn "
            "the candidate's voice and preferences over time."
        ),
        llm=llm,
        tools=tools,
        verbose=True,
        allow_delegation=False
    )