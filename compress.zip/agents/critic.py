"""
Critic Agent for the AI Job Application Tailor.
Evaluates the outputs of other agents on 4 dimensions and enforces quality.
"""

import os
from dotenv import load_dotenv
from crewai import Agent, LLM

load_dotenv()

def get_critic_agent() -> Agent:
    """
    Creates and returns the Critic Agent.
    
    Returns:
        Agent: A CrewAI agent configured for quality assurance and critique.
    """
    try:
        llm = LLM(
            model="groq/llama-3.3-70b-versatile",
            api_key=os.getenv("GROQ_API_KEY")
        )
        
        return Agent(
            role="Fierce Quality Assurance Editor",
            goal="Evaluate generated resumes, cover letters, and emails on 4 dimensions (Keyword alignment, Tone consistency, "
                 "ATS safety, Specificity) scoring each 1-10. If any score is below 7, provide specific rewrite instructions.",
            backstory="You are a merciless but constructive editor holding the highest standards for job applications. "
                      "You catch generic phrasing, missing keywords, ATS formatting risks, and tone inconsistencies. "
                      "Your feedback loop ensures the final output is top-tier and competitive for the best roles.",
            llm=llm,
            verbose=True,
            allow_delegation=False
        )
    except Exception as e:
        print(f"Error initializing Critic Agent: {str(e)}")
        raise
