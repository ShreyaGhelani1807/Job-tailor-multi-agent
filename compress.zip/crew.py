"""
Main Crew definition for the AI Job Application Tailor.
Assembles agents, tasks, and executes the hierarchical workflow.
"""

import os
import requests
from dotenv import load_dotenv
from crewai import Crew, Process, LLM

# Import agents
from agents.jd_analyser import create_jd_analyser
from agents.profile_parser import create_profile_parser
from agents.ats_scorer import create_ats_scorer
from agents.resume_tailor import create_resume_tailor
from agents.cover_letter import create_cover_letter_writer
from agents.cold_email import create_cold_email_writer
from agents.interview_prep import get_interview_prep_agent
from agents.manager import create_manager
from agents.memory_agent import create_memory_agent
from agents.critic import get_critic_agent

# Import tasks
from tasks.task_definitions import create_tasks

# Import tools
from tools.pdf_parser import PDFParserTool
from tools.scraper import ScraperTool
from tools.search import SearchTool
from tools.chroma_store import SaveApplicationTool, RetrieveSimilarTool

load_dotenv()

def send_n8n_webhook(payload: dict):
    """
    Sends the generated complete payload to the N8N webhook.
    """
    webhook_url = os.getenv("N8N_WEBHOOK_URL")
    if not webhook_url:
        print("Warning: N8N_WEBHOOK_URL not set. Skipping webhook execution.")
        return
        
    try:
        response = requests.post(webhook_url, json=payload, timeout=20)
        if response.status_code == 200:
            print("Successfully sent payload to N8N webhook.")
        else:
            print(f"Failed to send webhook. Status code: {response.status_code}")
    except Exception as e:
        print(f"Error sending payload to N8N: {str(e)}")

def run_crew(inputs: dict) -> dict:
    """
    Executes the CrewAI workflow and handles webhook delivery.
    
    Returns:
        dict: The combined outputs of the application tailor process.
    """
    try:
        # Initialize LLM
        llm = LLM(
            model="groq/llama-3.3-70b-versatile",
            api_key=os.getenv("GROQ_API_KEY")
        )

        # Initialize tools
        tools = [
            PDFParserTool(),
            ScraperTool(),
            SearchTool(),
            SaveApplicationTool(),
            RetrieveSimilarTool()
        ]

        # Instantiate agents
        manager = create_manager(llm)
        agents = {
            "jd_analyser": create_jd_analyser(llm, tools),
            "profile_parser": create_profile_parser(llm, tools),
            "ats_scorer": create_ats_scorer(llm, tools),
            "resume_tailor": create_resume_tailor(llm, tools),
            "cover_letter_writer": create_cover_letter_writer(llm, tools),
            "cold_email_writer": create_cold_email_writer(llm, tools),
            "interview_prep": get_interview_prep_agent(),
            "memory": create_memory_agent(llm, tools),
            "critic": get_critic_agent()
        }

        # Instantiate tasks
        tasks_dict = create_tasks(agents, inputs)
        
        # The manager oversees execution in hierarchical process
        crew = Crew(
            agents=list(agents.values()),
            tasks=list(tasks_dict.values()),
            process=Process.sequential,
            verbose=True
        )
        
        print("Kicking off Crew execution...")
        result = crew.kickoff()
        
        # Extract specific task outputs
        output_payload = {
            "ats_score": getattr(tasks_dict["score_ats"].output, 'raw', str(tasks_dict["score_ats"].output)),
            "tailored_resume": getattr(tasks_dict["tailor_resume"].output, 'raw', str(tasks_dict["tailor_resume"].output)),
            "cover_letter": getattr(tasks_dict["write_cover_letter"].output, 'raw', str(tasks_dict["write_cover_letter"].output)),
            "cold_email": getattr(tasks_dict["write_cold_email"].output, 'raw', str(tasks_dict["write_cold_email"].output)),
            "interview_prep": getattr(tasks_dict["prep_interview"].output, 'raw', str(tasks_dict["prep_interview"].output)),
            "critic_review": getattr(tasks_dict["critique_outputs"].output, 'raw', str(tasks_dict["critique_outputs"].output))
        }
        
        # Send to N8N webhook
        send_n8n_webhook(output_payload)
        
        return output_payload
        
    except Exception as e:
        print(f"Error during Crew execution: {str(e)}")
        raise
